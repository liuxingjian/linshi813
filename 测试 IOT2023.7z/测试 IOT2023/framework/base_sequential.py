#  FlowTransformer 2023 by liamdm / liam@riftcs.com
from framework.framework_component import FunctionalComponent

class BaseSequential(FunctionalComponent):
    pass