from tensorflow import keras
from keras_hub.src.layers.modeling.rotary_embedding import RotaryEmbedding
import numpy as np

#from keras_nlp.layers import RotaryEmbedding

class RotaryMultiHeadAttention(keras.layers.MultiHeadAttention):
    def __init__(self,max_sequence_length=128, **kwargs):
        super().__init__(**kwargs)
        # 初始化旋转位置编码层
        self.rotary_emb = RotaryEmbedding(
            max_wavelength=16, scaling_factor=1.0, sequence_axis=1, feature_axis=-1,
            name="rotary_embedding")

        self._max_sequence_length = max_sequence_length

    def _compute_attention(self, query, key, value, attention_mask=None,training=None,use_causal_mask=False):
        # 应用旋转位置编码到Q和K
        query = self.rotary_emb(query)  # [B, H, S, D]
        key = self.rotary_emb(key)      # [B, H, S, D]
        # 调用父类注意力计算逻辑
        return super()._compute_attention(query, key, value, attention_mask)

if __name__ == "__main__":
    batch_size = 16
    feature_length = 18
    sequence_length = 128
    num_heads = 8

    # No multi-head dimension.
    tensor = np.ones((batch_size, sequence_length, feature_length))
    att = RotaryMultiHeadAttention(num_heads=8, key_dim=feature_length)
    print(att(tensor,tensor))
