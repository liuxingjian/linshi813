import keras.layers as layers
import numpy as np
import tensorflow as tf
class PositionalEncoding(layers.Layer):
    def __init__(self, sequence_length, d_model):
        super(PositionalEncoding, self).__init__()
        self.sequence_length = sequence_length
        self.d_model = d_model

        # 生成位置编码矩阵
        position = np.arange(sequence_length)[:, np.newaxis]  # 位置索引 (sequence_length, 1)
        div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))  # 分母项

        pe = np.zeros((sequence_length, d_model))
        pe[:, 0::2] = np.sin(position * div_term)  # 偶数位置使用正弦
        pe[:, 1::2] = np.cos(position * div_term)  # 奇数位置使用余弦
        
        scale = 1
        # 将位置编码转换为 TensorFlow 张量
        self.pe = tf.convert_to_tensor(pe, dtype=tf.float32) * scale # 形状: (sequence_length, d_model)

    def call(self, inputs):
        # 将位置编码添加到输入中
        return inputs + self.pe  # 形状: (batch_size, sequence_length, d_model)

class RelativePositionalEncoding(layers.Layer):
    def __init__(self, max_relative_distance, d_model):
        super(RelativePositionalEncoding, self).__init__()
        self.max_relative_distance = max_relative_distance
        self.d_model = d_model

        # 生成相对位置编码矩阵
        relative_positions = np.arange(-max_relative_distance, max_relative_distance + 1)
        self.relative_encoding = self._generate_relative_encoding(relative_positions, d_model)

    def _generate_relative_encoding(self, relative_positions, d_model):
        # 生成相对位置编码（伪代码）
        pass

    def call(self, inputs):
        # 在注意力机制中应用相对位置编码
        pass

# 旋转位置编码 ds生成,kimi说对，只是需要一点优化，可以忽略
class RoPE(layers.Layer):
    def __init__(self, sequence_length, d_model, **kwargs):
        super(RoPE, self).__init__(**kwargs)
        self.sequence_length = sequence_length
        self.d_model = d_model

        # 初始化旋转角度的分母项
        div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))  # 形状: (d_model // 2,)
        self.div_term = tf.convert_to_tensor(div_term, dtype=tf.float32)  # 转换为 TensorFlow 张量

        # 生成位置索引
        position = np.arange(sequence_length)[:, np.newaxis]  # 形状: (sequence_length, 1)
        self.position = tf.convert_to_tensor(position, dtype=tf.float32)  # 转换为 TensorFlow 张量

    def call(self, inputs):
        """
        旋转位置编码实现
        :param inputs: 输入张量，形状为 (batch_size, sequence_length, d_model)
        :return: 添加位置编码后的输出，形状为 (batch_size, sequence_length, d_model)
        """
        # 计算旋转角度
        angle = self.position * self.div_term  # 形状: (sequence_length, d_model // 2)
        angle = tf.concat([angle, angle], axis=-1)  # 形状: (sequence_length, d_model)

        # 生成旋转矩阵
        cos_angle = tf.cos(angle)  # 形状: (sequence_length, d_model)
        sin_angle = tf.sin(angle)  # 形状: (sequence_length, d_model)

        # 将输入分为实部和虚部
        inputs_complex = tf.complex(inputs, tf.zeros_like(inputs))  # 形状: (batch_size, sequence_length, d_model)

        # 应用旋转矩阵
        rotation_matrix = tf.complex(cos_angle, sin_angle)  # 形状: (sequence_length, d_model)
        rotation_matrix = tf.expand_dims(rotation_matrix, axis=0)  # 形状: (1, sequence_length, d_model)
        outputs = inputs_complex * rotation_matrix  # 形状: (batch_size, sequence_length, d_model)

        # 返回实部作为输出
        return tf.math.real(outputs)  # 形状: (batch_size, sequence_length, d_model)
    
class RoPE_new(layers.Layer):
    def __init__(self, d_model, max_seq_len=512, theta=10000.0, **kwargs):
        super(RoPE_new, self).__init__(**kwargs)
        self.d_model = d_model
        self.max_seq_len = max_seq_len
        self.theta = theta
        
        # 预计算频率项 theta_i = 10000^(-2i/d_model)
        self.inverse_freq = 1.0 / (self.theta ** (tf.range(0, d_model, 2, dtype=tf.float32) / d_model))

    def build(self, input_shape):
        # 生成位置索引 [0, 1, ..., max_seq_len-1]
        self.position_ids = tf.range(self.max_seq_len, dtype=tf.float32)
        
        # 计算旋转角度：position_ids * inverse_freq
        freqs = tf.einsum("i,j->ij", self.position_ids, self.inverse_freq)
        self.cached_cos = tf.cos(freqs)  # 缓存cos值
        self.cached_sin = tf.sin(freqs)  # 缓存sin值

    def call(self, x, start_pos=0):
        """
        x: 输入张量，形状为 [batch_size, seq_len, d_model]
        start_pos: 起始位置（用于增量生成）
        """
        batch_size = tf.shape(x)[0]
        seq_len = tf.shape(x)[1]
        dim = tf.shape(x)[2]
        
        # 取缓存的cos和sin值（截断到当前序列长度）
        cos = self.cached_cos[start_pos : start_pos + seq_len]  # 形状: [seq_len, dim//2]
        sin = self.cached_sin[start_pos : start_pos + seq_len]  # 形状: [seq_len, dim//2]
        
        # 扩展维度以匹配输入张量 [seq_len, dim//2] -> [1, seq_len, dim//2]
        cos = tf.expand_dims(cos, axis=0)  # 形状: [1, seq_len, dim//2]
        sin = tf.expand_dims(sin, axis=0)  # 形状: [1, seq_len, dim//2]
        
        # 广播到 batch 维度 [1, seq_len, dim//2] -> [batch_size, seq_len, dim//2]
        cos = tf.tile(cos, [batch_size, 1, 1])  # 形状: [batch_size, seq_len, dim//2]
        sin = tf.tile(sin, [batch_size, 1, 1])  # 形状: [batch_size, seq_len, dim//2]
        
        # 将x拆分为两部分（对应复数实部和虚部）
        x1, x2 = tf.split(x, num_or_size_splits=2, axis=-1)  # 形状: [batch_size, seq_len, dim//2]
        
        # 旋转操作：[x1 * cos - x2 * sin, x1 * sin + x2 * cos]
        rotated_x1 = x1 * cos - x2 * sin  # 形状: [batch_size, seq_len, dim//2]
        rotated_x2 = x1 * sin + x2 * cos  # 形状: [batch_size, seq_len, dim//2]
        
        # 拼接旋转后的结果
        return tf.concat([rotated_x1, rotated_x2], axis=-1)  # 形状: [batch_size, seq_len, dim]