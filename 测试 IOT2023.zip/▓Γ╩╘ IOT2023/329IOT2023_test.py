from tensorflow import keras
from keras.models import model_from_json
from implementations.transformers.basic.encoder_block import TransformerEncoderBlock,TransformerEncoderBlock_position_encoding
import json
import os

from implementations.classification_heads import LastTokenClassificationHead
from implementations.transformers.basic_transformers import BasicTransformer
from implementations.transformers.named_transformers import GPTSmallTransformer

from framework.flow_transformer_parameters import FlowTransformerParameters
from framework.flow_transformer import FlowTransformer
from implementations.input_encodings import RecordLevelEmbed
from implementations.pre_processings import StandardPreProcessing

keras.config.enable_unsafe_deserialization()

with open("/home/yaojiahao/ydd_ws/FlowTransformer/models/IOT2023/m_model.json", "r") as jfile:
    model = model_from_json(json.load(jfile),custom_objects={'TransformerEncoderBlock': TransformerEncoderBlock,'TransformerEncoderBlock_position_encoding':TransformerEncoderBlock_position_encoding})
    model.load_weights("/home/yaojiahao/ydd_ws/FlowTransformer/models/IOT2023/m_model.weights.h5")

# We use several standard component to build our transformer
pre_processing = StandardPreProcessing(n_categorical_levels=32)
encoding = RecordLevelEmbed(64)
transformer = BasicTransformer(n_layers=2, internal_size=128, n_heads=2)
classification_head = LastTokenClassificationHead()

ft = FlowTransformer(pre_processing=pre_processing,
                     input_encoding=encoding,
                     sequential_model=transformer,
                     classification_head=classification_head,
                     params=FlowTransformerParameters(window_size=8, mlp_layer_sizes=[128], mlp_dropout=0.1))

from framework.dataset_specification import NamedDatasetSpecifications
from framework.enumerations import EvaluationDatasetSampling
flow_format = NamedDatasetSpecifications.iot2023

from framework.enumerations import EvaluationDatasetSampling


m = model
df = ft.load_dataset("IOT2023",
                "/home/yaojiahao/ydd_ws/nids-rl/datasets/CICIOT2023/min/0.1percent_8classes.csv",
                specification=flow_format,
                evaluation_dataset_sampling=EvaluationDatasetSampling.RandomRows,
                evaluation_percent=0.1,
                need_overanddownSampling=False)
ft.evaluate(m, batch_size=64, epochs=30, steps_per_epoch=64, early_stopping_patience=5)

res =  model.predict(ft.evx,verbose=True)
res = res.reshape(-1) > 0.5
print(res)
for i in res:
    print(i)